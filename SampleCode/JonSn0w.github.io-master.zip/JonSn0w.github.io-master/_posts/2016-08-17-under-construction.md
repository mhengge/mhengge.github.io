---
priority: 0.3
title: Site Under Construction...
desc: Still getting everything pieced together
date: 2016-08-17
categories: blog
options: nohead
background-image: posts\under_construction.png
tags:
  - blog
  - under construction
  - jekyll
---

This site is still under construction as I get everything pieced together. Consequently, you may find that there are still a few dead-links and holes that have yet to be patched up.  
All of which, should hopefully be running smoothly by the end of the week.   
