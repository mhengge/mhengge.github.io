---
priority: 0.5
title: Site Reconstruction...
desc:
date: 2017-03-31
categories: blog
options: nohead
background-image: posts\under_construction.png
tags:
  - blog
  - under construction
  - jekyll
---

I'm in the process of redesigning this website, though my previous site will remain active in the meantime.
